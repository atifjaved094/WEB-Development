const questions = [
  {
    progress: "1/4",
    text: "Why would you like to trade with bitcoin?",
    options: [
      "I like to increase my income",
      "I believe bitcoin is the future",
      "Investment purpose"
    ]
  },
  {
    progress: "2/4",
    text: "Do you have previous experience trading with bitcoin?",
    options: ["Yes", "No"]
  },
  {
    progress: "3/4",
    text: "How much would you like to profit per month?",
    options: [
      "$250–$1,000",
      "$1,000–$2,500",
      "$2,500–$5,000",
      "$5,000 and more"
    ]
  }
];

let current = 0;

function startQuestions() {
  document.getElementById("promo").style.display = "none";
  document.getElementById("questionWrapper").style.display = "block";

  const box = document.getElementById("questionBox");
  box.classList.remove("slide-in-left", "slide-in-right", "slide-out-left", "slide-out-right");
  box.classList.add("slide-in-right");

  updateQuestionContent(current);
}

function updateQuestionContent(index) {
  const q = questions[index];
  document.getElementById("progress").textContent = q.progress;
  document.getElementById("questionText").textContent = q.text;

  const container = document.getElementById("optionsContainer");
  container.innerHTML = "";
  q.options.forEach((opt, i) => {
    const id = `q${index}_opt${i}`;
    container.innerHTML += `
      <div class="form-check">
        <input class="form-check-input" type="radio" name="q${index}" id="${id}">
        <label class="form-check-label" for="${id}">${opt}</label>
      </div>
    `;
  });

  const box = document.getElementById("questionBox");
  box.classList.remove("show");
  setTimeout(() => {
    box.classList.add("show");
  }, 100);
}

function nextQuestion() {
  const box = document.getElementById("questionBox");
  box.classList.remove("slide-in-left", "slide-in-right", "slide-out-left", "slide-out-right");
  box.classList.add("slide-out-left");

  setTimeout(() => {
    current++;
    if (current < questions.length) {
      updateQuestionContent(current);
      box.classList.remove("slide-out-left");
      box.classList.add("slide-in-right");
    } else {
      document.getElementById("questionWrapper").style.display = "none";
      document.getElementById("rewardScreen").style.display = "block";
      document.getElementById("rewardScreen").classList.add("show");
    }
  }, 500);
}

function prevQuestion() {
  if (current > 0) {
    const box = document.getElementById("questionBox");
    box.classList.remove("slide-in-left", "slide-in-right", "slide-out-left", "slide-out-right");
    box.classList.add("slide-out-right");

    setTimeout(() => {
      current--;
      updateQuestionContent(current);
      box.classList.remove("slide-out-right");
      box.classList.add("slide-in-left");
    }, 500);
  }
}
