const loginForm = document.getElementById("loginForm");
const errorMsg = document.createElement("div"); // create error div dynamically
loginForm.appendChild(errorMsg); // attach to form

const correctUsername = "atif";
const correctPassword = "12345";

loginForm.addEventListener("submit", function(e) {
    e.preventDefault(); // stop page refresh

    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    if(username === correctUsername && password === correctPassword){
        window.location.href = "profile.html"; // go to profile
    } else {
        errorMsg.textContent = "Incorrect username or password!";
        errorMsg.style.color = "red";
        errorMsg.style.marginTop = "10px";
    }
});
